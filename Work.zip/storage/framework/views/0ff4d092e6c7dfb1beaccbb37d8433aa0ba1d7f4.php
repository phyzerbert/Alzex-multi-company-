<form action="" method="POST" class="form-inline float-left" id="searchForm">
    <?php echo csrf_field(); ?>
    <select class="form-control form-control-sm mr-sm-2 mb-2" name="type" id="search_type">
        <option value="" hidden><?php echo e(__('page.select_type')); ?></option>
        <option value="1" <?php if($type == 1): ?> selected <?php endif; ?>><?php echo e(__('page.expense')); ?></option>
        <option value="2" <?php if($type == 2): ?> selected <?php endif; ?>><?php echo e(__('page.incoming')); ?></option>
        <option value="3" <?php if($type == 3): ?> selected <?php endif; ?>><?php echo e(__('page.transfer')); ?></option>
    </select>
    <?php if(Auth::user()->hasRole('admin')): ?>
        <select class="form-control form-control-sm mr-sm-2 mb-2" name="company_id" id="search_company">
            <option value="" hidden><?php echo e(__('page.select_company')); ?></option>
            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>" data-icon="wallet" <?php if($company_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>                                            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
        </select>
    <?php endif; ?>
    <input type="text" class="form-control form-control-sm mr-sm-2 mb-2" name="description" id="search_description" value="<?php echo e($description); ?>" placeholder="<?php echo e(__('page.description')); ?>">
    <select class="form-control form-control-sm mr-sm-2 mb-2" name="account" id="search_account">
        <option value="" hidden><?php echo e(__('page.select_account')); ?></option>
        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" data-icon="wallet" <?php if($account == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>                                            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
    </select>
    <select class="form-control form-control-sm mr-sm-2 mb-2" name="category" id="search_category">
        <option value=""><?php echo e(__('page.select_category')); ?></option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php if($category == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <input type="text" class="form-control form-control-sm mr-sm-2 mb-2" name="period" id="period" autocomplete="off" value="<?php echo e($period); ?>" placeholder="<?php echo e(__('page.timestamp')); ?>" style="max-width:170px;">
    <button type="submit" class="btn btn-sm btn-primary mb-2"><i class="icon-search4"></i>&nbsp;&nbsp;<?php echo e(__('page.search')); ?></button>
    <button type="button" class="btn btn-sm btn-info mb-2 ml-1" id="btn-reset"><i class="icon-eraser"></i>&nbsp;&nbsp;<?php echo e(__('page.reset')); ?></button>
</form><?php /**PATH E:\2019-Jun\Alzex\MultiCompany\Work\resources\views/transaction/filter.blade.php ENDPATH**/ ?>