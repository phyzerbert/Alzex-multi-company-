<div class="header-elements d-flex">
    <div class="d-flex justify-content-center">
        <div class="btn-group justify-content-center">
            <a href="#" class="btn bg-primary-400 dropdown-toggle" data-toggle="dropdown"><i class="icon-wallet"></i>  <?php echo e(__('page.balance')); ?></a>
            <div class="dropdown-menu">
                <?php
                    $balance = \App\Models\Account::sum('balance');
                    $accounts = \App\Models\Account::all();
                    if (Auth::user()->hasRole('user')) {
                        $accounts = Auth::user()->company->accounts;
                        $balance = Auth::user()->company->accounts()->sum('balance');
                    }
                ?>
                <div class="dropdown-header dropdown-header-highlight"><?php echo e(__('page.total')); ?>:    <?php echo e($balance); ?></div>
                    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                         
                        <div class="dropdown-item">
                            <div class="flex-grow-1"><?php echo e($item->name); ?></div>
                            <div class="">                                                
                                <?php
                                    $account_expense = $item->expenses()->sum('amount');
                                    $account_incoming = $item->incomings()->sum('amount');
                                    $account_balance = $account_incoming - $account_expense;
                                ?>
                                <?php echo e(number_format( $account_balance)); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="dropdown-divider"></div>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\2019-Jun\Alzex\MultiCompany\Work\resources\views/elements/balance.blade.php ENDPATH**/ ?>