<?php $__env->startSection('content'); ?>
    <?php
        $verify_messages = [
            '10' => __('page.concurrent_verifications_to_the_same_number_are_not_allowed'),
            '4' => __('page.invalid_credentials_were_provided'),
            '5' => __('page.internal_error'),
        ];
    ?>     
    <div class="content d-flex justify-content-center align-items-center">
        <form class="login-form" action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="card mb-0">
                <div class="card-body">
                    <div class="text-center mb-3">
                        <img src="<?php echo e(asset('images/avatar128.png')); ?>" width="90" class="border-slate-300 border-3 rounded-round mb-2 mt-1" alt="">
                        
                        <h5 class="mb-0"><?php echo e(__('page.login_to_your_account')); ?></h5>
                        <span class="d-block text-muted"><?php echo e(__('page.enter_your_credentials_below')); ?></span>
                        <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                            <span class="text-danger mt-2" role="alert">
                                <strong>
                                    <?php if(isset($verify_messages[$message])): ?>
                                        <?php echo e($verify_messages[$message]); ?>

                                    <?php else: ?>
                                        <?php echo e(__('page.invalid_verification_request')); ?>

                                    <?php endif; ?>
                                </strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>

                    <div class="form-group form-group-feedback form-group-feedback-left">
                        <input type="text" name="name" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(__('page.username')); ?>" required autocomplete="name" autofocus>
                        <div class="form-control-feedback">
                            <i class="icon-user text-muted"></i>
                        </div>
                        <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                            <span class="invalid-feedback d-block" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>

                    <div class="form-group form-group-feedback form-group-feedback-left">                    
                        <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" placeholder="<?php echo e(__('page.password')); ?>" required autocomplete="current-password">
                        <div class="form-control-feedback">
                            <i class="icon-lock2 text-muted"></i>
                        </div>
                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                            <span class="invalid-feedback d-block" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>

                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" class="form-check-input-styled-primary" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> data-fouc="">
                            <?php echo e(__('page.remember_me')); ?>

                        </label>
                    </div>

                    <div class="form-group mt-3">
                        <button type="submit" class="btn btn-primary btn-block"><?php echo e(__('page.sign_in')); ?> <i class="icon-circle-right2 ml-2"></i></button>
                    </div>
                    
                    <div class="form-group text-center">
                        <a href="<?php echo e(route('lang', 'en')); ?>" class="btn btn-outline p-0 <?php if(config('app.locale') == 'en'): ?> border-primary border-2 <?php endif; ?>" title="English"><img src="<?php echo e(asset('images/lang/en.png')); ?>" width="45px"></a>
                        <a href="<?php echo e(route('lang', 'es')); ?>" class="btn btn-outline ml-2 p-0 <?php if(config('app.locale') == 'es'): ?> border-primary border-2 <?php endif; ?>" title="Spanish"><img src="<?php echo e(asset('images/lang/es.png')); ?>" width="45px"></a>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script src="<?php echo e(asset('master/global_assets/js/plugins/forms/styling/uniform.min.js')); ?>"></script>
	<script src="<?php echo e(asset('master/assets/js/login.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2019-Jun\Alzex\MultiCompany\Work\resources\views/auth/login.blade.php ENDPATH**/ ?>